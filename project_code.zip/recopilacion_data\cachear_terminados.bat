@echo off
cd ..
echo ==========================================
echo CACHEAR PARTIDOS TERMINADOS
echo (Igual que el boton "Cachear" de la web)
echo ==========================================
echo.
echo Esto scrapea partidos terminados de la pagina principal
echo y los guarda en los buckets de data_ah_*.json
echo.
py -u recopilacion_data/wrapper_cachear_terminados.py
echo.
echo Proceso completado.
pause
