import sys
import os
from pathlib import Path

# Add project root to sys.path
project_root = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(project_root))

from src.app import process_all_finished_matches_background_with_workers

# Configuración de workers
DEFAULT_WORKERS = 10  # Óptimo para velocidad sin riesgo de bloqueo

if __name__ == "__main__":
    print("=" * 50)
    print("CACHEAR TERMINADOS (como botón Cachear)")
    print("=" * 50)
    print("Scrapea partidos terminados de NowGoal")
    print("y los guarda en los buckets data_ah_*.json")
    print()
    
    # Argumentos: [handicap] [ou] [workers]
    handicap_filter = None
    goal_line_filter = None
    workers = DEFAULT_WORKERS
    
    if len(sys.argv) > 1:
        handicap_filter = sys.argv[1] if sys.argv[1] != 'all' else None
    if len(sys.argv) > 2:
        goal_line_filter = sys.argv[2] if sys.argv[2] != 'all' else None
    if len(sys.argv) > 3:
        try:
            workers = int(sys.argv[3])
        except:
            pass
    
    print(f"Configuración:")
    print(f"  • Filtro AH: {handicap_filter or 'Todos'}")
    print(f"  • Filtro OU: {goal_line_filter or 'Todos'}")
    print(f"  • Workers: {workers}")
    print()
    
    try:
        process_all_finished_matches_background_with_workers(
            handicap_filter=handicap_filter,
            goal_line_filter=goal_line_filter,
            workers=workers
        )
        print()
        print("Proceso de cacheo completado.")
    except Exception as e:
        print(f"Error durante el cacheo: {e}")
