import sys
import os
from pathlib import Path

# Add project root to sys.path
project_root = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(project_root))

from src.app import process_upcoming_matches_background

if __name__ == "__main__":
    print("Iniciando 'Scrapear Pendientes' (Pre-Cacheo)...")
    
    # Debug Paths
    try:
        from src.modules import data_manager
        print(f"DEBUG: Data Manager Dir: {data_manager.DATA_DIR}")
        from src import app
        print(f"DEBUG: App Data File: {app.DATA_FILE}")
    except Exception as e:
        print(f"DEBUG Error inspecting paths: {e}")

    # Leer workers de argumentos
    workers = 8
    if len(sys.argv) > 1:
        try:
            workers = int(sys.argv[1])
        except:
            pass

    print(f"Configuración: Workers={workers}")

    try:
        process_upcoming_matches_background(handicap_filter=None, goal_line_filter=None, workers=workers)
        print("Scraping de pendientes completado.")
    except Exception as e:
        print(f"Error durante el scraping: {e}")
